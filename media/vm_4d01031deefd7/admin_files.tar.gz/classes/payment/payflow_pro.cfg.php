<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('PFP_TEST_REQUEST', 'TRUE');
define ('PFP_PARTNER', 'XXXXX');
define ('PFP_VENDOR', 'XXXXX');
define ('PFP_USER', 'XXXXX');
define ('PFP_CHECK_CARD_CODE', 'YES');
define ('PFP_VERIFIED_STATUS', 'P');
define ('PFP_INVALID_STATUS', 'P');
?>