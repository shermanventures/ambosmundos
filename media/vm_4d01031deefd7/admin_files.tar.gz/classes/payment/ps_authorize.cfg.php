<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('AN_TEST_REQUEST', 'TRUE');
define ('AN_LOGIN', 'LoginID344f');
define ('AN_TYPE', 'AUTH_CAPTURE');
define ('AN_CHECK_CARD_CODE', 'YES');
define ('AN_VERIFIED_STATUS', 'P');
define ('AN_INVALID_STATUS', 'P');
define ('AN_RECURRING', 'NO');
define ('AN_EMAIL_MERCHANT', 'YES');
define ('AN_EMAIL_CUSTOMER', 'YES');
define ('AN_SHOW_ERROR_CODE', 'YES');
?>