<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('MO_CHECK_CARD_CODE', 'YES');
define ('MO_VERIFIED_STATUS', 'C');
define ('MO_INVALID_STATUS', 'P');
define ('MO_USERNAME', 'xxxx');
define ('MO_PASSWORD', 'xxxx');
?>