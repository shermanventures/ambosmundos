<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('IPAYMENT_ACCOUNTID', '11111111111');
define ('IPAYMENT_APPID', '2222');
define ('IPAYMENT_APP_PASSWORD', '333333333');
define ('IPAYMENT_ACTION_PASSWORD', 'vm46vm46vm46vm46');
define ('IPAYMENT_SECRET', 'vmvmvmvmvmvmv45646464');
define ('IPAYMENT_VERIFIED_STATUS', 'C');
define ('IPAYMENT_PENDING_STATUS', 'P');
define ('IPAYMENT_INVALID_STATUS', 'X');
?>