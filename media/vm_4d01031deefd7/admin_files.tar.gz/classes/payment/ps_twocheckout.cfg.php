<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('TWOCO_LOGIN', 'xxxxxxxxxx');
define ('TWOCO_SECRETWORD', 'mysecret');
define ('TWOCO_VERIFIED_STATUS', 'C');
define ('TWOCO_INVALID_STATUS', 'X');
define ('TWOCO_TESTMODE', 'Y');
define ('TWOCO_MERCHANT_EMAIL', 'True');
?>