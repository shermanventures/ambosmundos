<?php
if( !defined( '_VALID_MOS' ) && !defined( '_JEXEC' ) ) die( 'Direct Access to '.basename(__FILE__).' is not allowed.' ); 

define ('DHL_ID', 'Your ID');
define ('DHL_PASSWORD', 'Your Password');
define ('DHL_DOMESTIC_SHIPPING_KEY', 'A long hex value');
define ('DHL_INTERNATIONAL_SHIPPING_KEY', 'A long hex value');
define ('DHL_ACCOUNT_NUMBER', 'Your Acct. Nbr.');
define ('DHL_TOO_LATE', '1600');
define ('DHL_TEST_MODE', 'TRUE');
define ('DHL_EXPRESS_ENABLED', 'TRUE');
define ('DHL_NEXT_AFTERNOON_ENABLED', 'TRUE');
define ('DHL_SECOND_DAY_ENABLED', 'TRUE');
define ('DHL_GROUND_ENABLED', 'TRUE');
define ('DHL_1030_ENABLED', 'TRUE');
define ('DHL_SATURDAY_ENABLED', 'TRUE');
define ('DHL_INTERNATIONAL_ENABLED', 'TRUE');
define ('DHL_DOMESTIC_PACKAGE', 'P');
define ('DHL_INTERNATIONAL_PACKAGE', 'O');
define ('DHL_CONTENT_DESC', 'Bitching stuff');
define ('DHL_PACKAGE_WEIGHT', '1.0');
define ('DHL_DUTY_SHOPPER_GROUP', 'DUTY');
define ('DHL_ADDITIONAL_PROTECTION', 'AP');
define ('DHL_INSURANCE_SHOPPER_GROUP', 'INSURANCE');
define ('DHL_INSURANCE_RATE_DOMESTIC_FLAT', '100.00');
define ('DHL_INSURANCE_RATE_INTERNATIONAL', '9.07');
define ('DHL_TAX_CLASS', '0');
define ('DHL_HANDLING_FEE', '2.50');
?>
